#ifndef BUZZER_H
#define BUZZER_H

#include <Arduino.h>

void Buzzer_init();
void Buzzer_on();
void Buzzer_off();
void setBuzzer(int s);

#endif
