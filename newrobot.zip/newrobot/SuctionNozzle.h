#ifndef SUCTIONNOZZLE_H
#define SUCTIONNOZZLE_H

void Nozzle_init(void);
void Pump_on(void);
void Valve_on(void);
void Valve_off(void);

#endif
